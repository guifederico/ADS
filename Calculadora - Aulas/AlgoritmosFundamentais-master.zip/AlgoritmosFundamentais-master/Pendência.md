Notação markdown
# Pendências
- [ ] Luiza -> CSS do vetor de entrada na páginas Ordanada e Somatório
- [ ] Aplciar include dos btnEnviar


# Apresentação
- Redução de Código e Ajuste - Kevin
- Front/Outro - Luiza
- Paginas
- Elementos/Layout/Utilidades
